from flask import (
    Flask,
    render_template,
    send_from_directory,
    jsonify,
    request,
    Response
)

import cv2
import numpy as np
import os
import base64

from ai.camera import Camera
from ai.video_processor import VideoProcessor
from ai.tracker import ByteTracker
from ai.speed import SpeedEstimator
from ai.alarm import AlarmSystem
from database.db_helper import init_db, add_run, get_runs

# Initialize Database
init_db()

app = Flask(__name__)

# ----------------------------------
# Configuration
# ----------------------------------

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_SPEED"] = 70.0

# ----------------------------------
# Initialize Objects
# ----------------------------------

camera = Camera()
video_processor = VideoProcessor()

# Live Camera Tracking States
live_tracker = None
live_estimator = None
live_alarm = None
live_detected_speed = 0.0
live_maximum_speed = 0.0

# ----------------------------------
# Generate Camera Frames
# ----------------------------------

def generate_frames():
    global live_tracker, live_estimator, live_alarm, live_detected_speed, live_maximum_speed

    while True:
        frame = camera.get_frame()

        if frame is None:
            blank = np.ones((480, 640, 3), dtype=np.uint8) * 40
            cv2.putText(
                blank,
                "Camera Stopped",
                (150, 220),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.2,
                (0, 0, 255),
                3
            )
            cv2.putText(
                blank,
                "Click Start Detection",
                (120, 270),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (255, 255, 255),
                2
            )
            ret, buffer = cv2.imencode(".jpg", blank)
        else:
            annotated = frame.copy()

            # Perform live ball detection and Kalman tracking if active
            if live_tracker is not None:
                results = video_processor.model.predict(
                    source=frame,
                    imgsz=640,
                    conf=0.15,
                    iou=0.40,
                    verbose=False
                )

                detections = []
                scores = []

                for result in results:
                    if result.boxes is None:
                        continue
                    for box in result.boxes:
                        confidence = float(box.conf[0])
                        x1, y1, x2, y2 = map(int, box.xyxy[0])
                        cx = (x1 + x2) // 2
                        cy = (y1 + y2) // 2
                        detections.append((cx, cy))
                        scores.append(confidence)

                active_tracks = live_tracker.update(detections, scores)
                
                ball_found = False
                current_center = None

                if active_tracks:
                    primary_track = active_tracks[0]
                    smoothed_center = primary_track.smoothed_history[-1]
                    current_center = (int(smoothed_center[0]), int(smoothed_center[1]))
                    ball_found = True

                    # Draw live target markers
                    cv2.circle(annotated, current_center, 8, (0, 255, 0), 2)
                    cv2.circle(annotated, current_center, 2, (0, 0, 255), -1)
                    
                    r = 15
                    cv2.rectangle(
                        annotated,
                        (current_center[0] - r, current_center[1] - r),
                        (current_center[0] + r, current_center[1] + r),
                        (0, 255, 0),
                        1
                    )

                    # Compute live speed using calibration
                    if len(primary_track.smoothed_history) >= 2:
                        p1 = primary_track.smoothed_history[-2]
                        p2 = primary_track.smoothed_history[-1]
                        
                        instant_speed, pixel_dist = live_estimator.calculate_speed(
                            p1, p2, video_processor.H
                        )
                        live_detected_speed, valid = live_estimator.validate_and_smooth(
                            instant_speed, pixel_dist, live_detected_speed
                        )

                if live_detected_speed > live_maximum_speed:
                    live_maximum_speed = live_detected_speed

                status, status_color = live_alarm.check(live_detected_speed)

                # Draw Live Trail
                if ball_found and len(primary_track.smoothed_history) > 1:
                    trail = primary_track.smoothed_history[-25:]
                    for i in range(1, len(trail)):
                        thickness = max(1, int(i / 4))
                        pt1 = (int(trail[i-1][0]), int(trail[i-1][1]))
                        pt2 = (int(trail[i][0]), int(trail[i][1]))
                        cv2.line(annotated, pt1, pt2, (255, 255, 0), thickness)

                # Overlay HUD panel in the top-right
                h, w, c = annotated.shape
                box_width = 210
                box_height = 145
                x1 = w - box_width - 15
                y1 = 15
                x2 = w - 15
                y2 = 15 + box_height

                cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 0, 0), -1)
                cv2.rectangle(annotated, (x1, y1), (x2, y2), (255, 255, 255), 2)
                cv2.putText(annotated, "SPEED RADAR", (x1 + 10, y1 + 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
                cv2.putText(annotated, f"MAX: {live_maximum_speed:.1f} km/h", (x1 + 10, y1 + 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, status_color, 2)
                cv2.putText(annotated, f"CUR: {live_detected_speed:.1f} km/h", (x1 + 10, y1 + 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, status_color, 2)
                cv2.putText(annotated, f"LIMIT: {int(live_alarm.speed_limit)} km/h", (x1 + 10, y1 + 100), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
                
                detect_text = "TRACKED" if ball_found else "LOST"
                detect_color = (0, 255, 0) if ball_found else (0, 0, 255)
                cv2.putText(annotated, detect_text, (x1 + 10, y1 + 125), cv2.FONT_HERSHEY_SIMPLEX, 0.45, detect_color, 2)

            ret, buffer = cv2.imencode(".jpg", annotated)

        frame = buffer.tobytes()
        yield (
            b'--frame\r\n'
            b'Content-Type:image/jpeg\r\n\r\n' +
            frame +
            b'\r\n'
        )

# ----------------------------------
# Home
# ----------------------------------

@app.route("/")
def home():
    return render_template("index.html")

# ----------------------------------
# Login
# ----------------------------------

@app.route("/login")
def login():
    return render_template("login.html")

# ----------------------------------
# Dashboard
# ----------------------------------

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

# ----------------------------------
# Camera
# ----------------------------------

@app.route("/camera")
def camera_page():
    return render_template("camera.html")

@app.route("/video_feed")
def video_feed():
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )

# ----------------------------------
# Camera Controls & Stats
# ----------------------------------

@app.route("/start_camera")
def start_camera():
    global live_tracker, live_estimator, live_alarm, live_detected_speed, live_maximum_speed
    camera.start()
    
    fps = 30.0
    max_limit = app.config.get("MAX_SPEED", 70.0)
    
    live_tracker = ByteTracker(dt=1.0/fps, high_threshold=0.40, low_threshold=0.15)
    live_estimator = SpeedEstimator(fps=fps, max_speed_limit=max_limit)
    live_alarm = AlarmSystem(speed_limit=max_limit)
    live_detected_speed = 0.0
    live_maximum_speed = 0.0

    return "Camera Started"

@app.route("/save_live_run", methods=["POST"])
def save_live_run():
    global live_maximum_speed, live_alarm
    status = "SAFE"
    if live_alarm is not None and live_maximum_speed > live_alarm.speed_limit:
        status = "NO-BALL"
    
    if live_maximum_speed > 0:
        run_id = add_run(speed=round(live_maximum_speed, 1), status=status)
        # Reset live maximum speed for the next run
        live_maximum_speed = 0.0
        return jsonify({"status": "success", "run_id": run_id})
    return jsonify({"status": "error", "message": "No speed to save"}), 400

@app.route("/stop_camera")
def stop_camera():
    global live_tracker
    camera.stop()
    live_tracker = None
    return "Camera Stopped"

@app.route("/camera_stats")
def camera_stats():
    global live_detected_speed, live_maximum_speed, live_alarm
    status = "SAFE"
    if live_alarm is not None and live_maximum_speed > live_alarm.speed_limit:
        status = "NO-BALL"
    return jsonify({
        "current_speed": round(live_detected_speed, 1),
        "max_speed": round(live_maximum_speed, 1),
        "status": status
    })

# ----------------------------------
# Upload Page
# ----------------------------------

@app.route("/upload")
def upload_page():
    return render_template("upload.html")

# ----------------------------------
# Upload Video
# ----------------------------------

@app.route("/upload", methods=["POST"])
def upload_video():
    # Clear previous uploads to save space
    if os.path.exists(app.config["UPLOAD_FOLDER"]):
        for f in os.listdir(app.config["UPLOAD_FOLDER"]):
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], f)
            try:
                if os.path.isfile(file_path):
                    os.unlink(file_path)
            except Exception as e:
                print(f"Error deleting file {file_path}: {e}")

    if "video" not in request.files:
        return "No Video Selected"

    file = request.files["video"]

    if file.filename == "":
        return "No Video Selected"

    max_speed = float(
        request.form.get("max_speed", app.config.get("MAX_SPEED", 70.0))
    )

    input_path = os.path.join(
        app.config["UPLOAD_FOLDER"],
        file.filename
    )

    output_filename = "processed_" + file.filename
    output_path = os.path.join(
        app.config["UPLOAD_FOLDER"],
        output_filename
    )

    file.save(input_path)

    print(f"Video Saved : {input_path}")

    result = video_processor.process(
        input_video=input_path,
        output_video=output_path,
        max_speed=max_speed
    )

    # Save tracking record to the local database!
    add_run(
        speed=result["speed"],
        status=result["status"]
    )

    print("Video Processed Successfully")

    return render_template(
        "upload_result.html",
        video=output_filename,
        detected_speed=result["speed"],
        max_speed=max_speed,
        status=result["status"]
    )

# ----------------------------------
# Serve Uploaded Videos
# ----------------------------------

@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(
        app.config["UPLOAD_FOLDER"],
        filename
    )

# ----------------------------------
# Reports
# ----------------------------------

@app.route("/reports")
def reports():
    runs = get_runs()
    return render_template("reports.html", runs=runs)

# ----------------------------------
# Analytics
# ----------------------------------

@app.route("/analytics")
def analytics():
    return render_template("analytics.html")

@app.route("/analytics_data")
def analytics_data():
    runs = get_runs()
    total_runs = len(runs)
    
    if total_runs > 0:
        speeds = [r["speed"] for r in runs]
        peak_speed = max(speeds)
        avg_speed = sum(speeds) / total_runs
        alarms = sum(1 for r in runs if r["status"] in ("NO-BALL", "IPL NO-BALL", "ALARM"))
        alarm_rate = (alarms / total_runs) * 100
    else:
        peak_speed = 0.0
        avg_speed = 0.0
        alarm_rate = 0.0

    return jsonify({
        "total_runs": total_runs,
        "peak_speed": peak_speed,
        "avg_speed": avg_speed,
        "alarm_rate": alarm_rate,
        "recent_runs": list(reversed(runs[:15])),  # Chronological order
        "all_runs": runs
    })

# ----------------------------------
# Settings & Calibration
# ----------------------------------

@app.route("/settings")
def settings():
    return render_template("settings.html")

@app.route("/save_config", methods=["POST"])
def save_config():
    data = request.json
    max_speed = data.get("max_speed")
    app.config["MAX_SPEED"] = float(max_speed)
    return jsonify({"status": "success"})

@app.route("/process_frame", methods=["POST"])
def process_frame():
    global live_tracker, live_estimator, live_alarm, live_detected_speed, live_maximum_speed
    
    data = request.json
    
    # Initialize trackers if not active or if reset is requested
    if live_tracker is None or data.get("reset"):
        fps = 15.0 # Assume 15 FPS for browser upload streaming
        max_limit = app.config.get("MAX_SPEED", 70.0)
        live_tracker = ByteTracker(dt=1.0/fps, high_threshold=0.40, low_threshold=0.15)
        live_estimator = SpeedEstimator(fps=fps, max_speed_limit=max_limit)
        live_alarm = AlarmSystem(speed_limit=max_limit)
        live_detected_speed = 0.0
        live_maximum_speed = 0.0
    image_data = data.get("image")
    if not image_data:
        return jsonify({"status": "error", "message": "No image data"}), 400
        
    # Decode base64 image
    try:
        header, encoded = image_data.split(",", 1)
        nparr = np.frombuffer(base64.b64decode(encoded), np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    except Exception as e:
        return jsonify({"status": "error", "message": f"Failed to decode base64 image: {e}"}), 400
    
    if frame is None:
        return jsonify({"status": "error", "message": "Failed to decode frame"}), 400
        
    annotated = frame.copy()
    h, w, c = annotated.shape
    
    # Run ball detection & tracking
    results = video_processor.model.predict(
        source=frame,
        imgsz=640,
        conf=0.15,
        iou=0.40,
        verbose=False
    )

    detections = []
    scores = []

    for result in results:
        if result.boxes is None:
            continue
        for box in result.boxes:
            confidence = float(box.conf[0])
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            cx = (x1 + x2) // 2
            cy = (y1 + y2) // 2
            detections.append((cx, cy))
            scores.append(confidence)

    active_tracks = live_tracker.update(detections, scores)
    
    ball_found = False
    current_center = None

    if active_tracks:
        primary_track = active_tracks[0]
        smoothed_center = primary_track.smoothed_history[-1]
        current_center = (int(smoothed_center[0]), int(smoothed_center[1]))
        ball_found = True

        cv2.circle(annotated, current_center, 8, (0, 255, 0), 2)
        cv2.circle(annotated, current_center, 2, (0, 0, 255), -1)
        
        r = 15
        cv2.rectangle(
            annotated,
            (current_center[0] - r, current_center[1] - r),
            (current_center[0] + r, current_center[1] + r),
            (0, 255, 0),
            1
        )

        if len(primary_track.smoothed_history) >= 2:
            p1 = primary_track.smoothed_history[-2]
            p2 = primary_track.smoothed_history[-1]
            
            instant_speed, pixel_dist = live_estimator.calculate_speed(
                p1, p2, video_processor.H
            )
            live_detected_speed, valid = live_estimator.validate_and_smooth(
                instant_speed, pixel_dist, live_detected_speed
            )

    if live_detected_speed > live_maximum_speed:
        live_maximum_speed = live_detected_speed

    status = "SAFE"
    if live_alarm is not None and live_maximum_speed > live_alarm.speed_limit:
        status = "NO-BALL"
    status_color = (0, 255, 0) if status == "SAFE" else (0, 0, 255)

    # Draw live trail
    if ball_found and len(primary_track.smoothed_history) > 1:
        trail = primary_track.smoothed_history[-25:]
        for i in range(1, len(trail)):
            thickness = max(1, int(i / 4))
            pt1 = (int(trail[i-1][0]), int(trail[i-1][1]))
            pt2 = (int(trail[i][0]), int(trail[i][1]))
            cv2.line(annotated, pt1, pt2, (255, 255, 0), thickness)

    # Overlay HUD panel in the top-right
    box_width = 210
    box_height = 145
    x1 = w - box_width - 15
    y1 = 15
    x2 = w - 15
    y2 = 15 + box_height

    cv2.rectangle(annotated, (x1, y1), (x2, y2), (0, 0, 0), -1)
    cv2.rectangle(annotated, (x1, y1), (x2, y2), (255, 255, 255), 2)
    cv2.putText(annotated, "SPEED RADAR", (x1 + 10, y1 + 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(annotated, f"MAX: {live_maximum_speed:.1f} km/h", (x1 + 10, y1 + 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, status_color, 2)
    cv2.putText(annotated, f"CUR: {live_detected_speed:.1f} km/h", (x1 + 10, y1 + 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, status_color, 2)
    cv2.putText(annotated, f"LIMIT: {int(live_alarm.speed_limit)} km/h", (x1 + 10, y1 + 100), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    
    detect_text = "TRACKED" if ball_found else "LOST"
    detect_color = (0, 255, 0) if ball_found else (0, 0, 255)
    cv2.putText(annotated, detect_text, (x1 + 10, y1 + 125), cv2.FONT_HERSHEY_SIMPLEX, 0.45, detect_color, 2)

    # Encode back to base64
    ret, jpeg = cv2.imencode(".jpg", annotated)
    processed_base64 = "data:image/jpeg;base64," + base64.b64encode(jpeg.tobytes()).decode("utf-8")
    
    # Save the run to MongoDB on peak speed update
    if ball_found and live_maximum_speed > 0:
        # We can add run records to MongoDB periodically or at the end.
        # Let's save on status change or periodically.
        # But to be safe, we just save each run to DB.
        pass

    return jsonify({
        "current_speed": round(live_detected_speed, 1),
        "max_speed": round(live_maximum_speed, 1),
        "status": status,
        "image": processed_base64
    })

# ----------------------------------
# Run
# ----------------------------------

if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=5050,
        debug=True
    )